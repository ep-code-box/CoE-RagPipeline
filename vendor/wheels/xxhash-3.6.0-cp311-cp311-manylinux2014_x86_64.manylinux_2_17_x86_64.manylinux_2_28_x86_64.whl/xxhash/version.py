VERSION = "3.6.0"
#: Deprecated, will be removed in the next major release
VERSION_TUPLE = (3, 6, 0)
