"""Tools package for OpenAI integrations."""

from langchain_openai.tools.custom_tool import custom_tool

__all__ = ["custom_tool"]
