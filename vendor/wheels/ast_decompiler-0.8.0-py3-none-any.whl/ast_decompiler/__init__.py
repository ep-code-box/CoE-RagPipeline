"""

Generate Python code given an AST.

"""

__version__ = "0.7.0"

from .decompiler import decompile as decompile
